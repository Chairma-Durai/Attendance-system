Write operation:

1.Run the Write.py script
2.It will ask you to enter the data
3.enter the data and click enter,now place your RFID tag near reader.
4.The given data will be flashed to the card.

Read operation:
1.Place the RFID tag near the reader
2.the program will display the output data obtained from the card. 

Note:The script is already added to the main program-train.py